module.exports = {
	PORT: 5000,
	DB_HOST: "localhost",
	DB_USER: "root",
	DB_PASSWORD: "",
	DB_DATABASE: "health_hub",
	JWT_SECRET: "67JHKNJfjfY787@#$",
};
